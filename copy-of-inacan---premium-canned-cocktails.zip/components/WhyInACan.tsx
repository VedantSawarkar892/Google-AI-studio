import React from 'react';
import { motion } from 'framer-motion';

const WhyInACan: React.FC = () => {
  const items = [
    {
      image: "https://images.unsplash.com/photo-1613208753235-5a557b98d975?auto=format&fit=crop&w=200&q=80",
      title: "High-Quality Alcohol",
      desc: "Alcohol distilled specifically for INACAN with standardized mixes and consistent taste."
    },
    {
      image: "https://images.unsplash.com/photo-1516550135131-fe3dcb0bedc7?auto=format&fit=crop&w=200&q=80",
      title: "In-House Blended",
      desc: "DIAGEO World Class winning mixologist heading the product innovation."
    },
    {
      image: "https://images.unsplash.com/photo-1622483767028-3f66f32aef97?auto=format&fit=crop&w=200&q=80",
      title: "Effortless Convenience",
      desc: "Approx. service time is 5 seconds. Just chill, pop and enjoy."
    }
  ];

  return (
    <section className="py-32 px-6 bg-zinc-900/30 border-y border-white/5 relative overflow-hidden">
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="text-center mb-20">
            <span className="text-yellow-400 uppercase tracking-[0.3em] text-xs font-bold">The Difference</span>
            <h2 className="text-4xl md:text-5xl font-serif mt-4 text-white">WHY INACAN?</h2>
        </div>
        
        <div className="grid md:grid-cols-3 gap-12">
          {items.map((item, index) => (
            <motion.div 
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
              className="text-center space-y-6 group p-8 rounded-2xl hover:bg-zinc-900/50 transition-colors"
            >
              <div className="w-24 h-24 mx-auto flex items-center justify-center rounded-full overflow-hidden border-2 border-zinc-800 group-hover:border-yellow-400/50 transition-colors duration-500">
                <img 
                  src={item.image} 
                  alt={item.title}
                  className="w-full h-full object-cover opacity-70 group-hover:opacity-100 group-hover:scale-110 transition-all duration-500"
                />
              </div>
              <h3 className="text-xl font-bold uppercase tracking-wide text-white">{item.title}</h3>
              <p className="text-zinc-400 text-sm leading-relaxed max-w-xs mx-auto">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyInACan;