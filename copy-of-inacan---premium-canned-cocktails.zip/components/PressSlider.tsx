import React from 'react';
import { motion } from 'framer-motion';

const pressItems = [
  { name: 'Vir Sanghvi', image: 'https://images.unsplash.com/photo-1572116469696-31de0f17cc34?auto=format&fit=crop&w=800&q=80', quote: "A revolution in the making." },
  { name: 'Tullleeho', image: 'https://images.unsplash.com/photo-1566737236500-c8ac43014a67?auto=format&fit=crop&w=800&q=80', quote: "Finally, a canned cocktail that tastes real." },
  { name: 'LBB Insider', image: 'https://images.unsplash.com/photo-1605218427368-35b0b304c062?auto=format&fit=crop&w=800&q=80', quote: "The best thing to happen to house parties." }
];

const PressSlider: React.FC = () => {
  return (
    <section className="py-32 px-6 bg-zinc-950">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-center text-3xl md:text-4xl font-light mb-20 font-serif tracking-tight">IN THE PRESS</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {pressItems.map((press, index) => (
            <motion.div 
              key={index}
              whileHover={{ y: -10 }} 
              className="bg-zinc-900/50 p-8 rounded-2xl border border-zinc-800/50 hover:border-zinc-700 transition-all group"
            >
              <div className="h-48 bg-zinc-800 mb-8 rounded-lg overflow-hidden relative">
                 <div className="absolute inset-0 bg-indigo-900/10 mix-blend-overlay group-hover:opacity-0 transition-opacity"></div>
                 <img 
                    src={press.image} 
                    alt={press.name} 
                    className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700" 
                 />
              </div>
              <h4 className="text-xl font-bold uppercase tracking-wider text-white mb-2">{press.name}</h4>
              <p className="text-zinc-500 text-sm italic mb-6">"{press.quote}"</p>
              <button className="text-xs font-bold border-b border-yellow-400 pb-1 uppercase tracking-widest text-yellow-400 hover:text-white hover:border-white transition-colors">
                Read Article
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PressSlider;