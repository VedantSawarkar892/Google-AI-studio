import React from 'react';
import { Instagram, Twitter, Facebook } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-zinc-950 border-t border-zinc-900 pt-24 pb-12 px-6">
      <div className="max-w-7xl mx-auto grid md:grid-cols-4 gap-12 mb-16">
        <div className="space-y-6">
          <h3 className="text-2xl font-serif font-bold">INACAN</h3>
          <p className="text-zinc-500 text-sm leading-relaxed">
            Crafting premium cocktail experiences in a convenient format. 
            Award-winning mixes, zero compromise.
          </p>
        </div>
        
        <div>
          <h4 className="text-sm font-bold uppercase tracking-widest mb-6 text-white">Explore</h4>
          <ul className="space-y-4 text-zinc-500 text-sm">
            <li className="hover:text-yellow-400 cursor-pointer transition-colors">Our Cocktails</li>
            <li className="hover:text-yellow-400 cursor-pointer transition-colors">The Distillery</li>
            <li className="hover:text-yellow-400 cursor-pointer transition-colors">Sustainability</li>
            <li className="hover:text-yellow-400 cursor-pointer transition-colors">Careers</li>
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-bold uppercase tracking-widest mb-6 text-white">Support</h4>
          <ul className="space-y-4 text-zinc-500 text-sm">
            <li className="hover:text-yellow-400 cursor-pointer transition-colors">Contact Us</li>
            <li className="hover:text-yellow-400 cursor-pointer transition-colors">FAQ</li>
            <li className="hover:text-yellow-400 cursor-pointer transition-colors">Shipping & Returns</li>
            <li className="hover:text-yellow-400 cursor-pointer transition-colors">Privacy Policy</li>
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-bold uppercase tracking-widest mb-6 text-white">Social</h4>
          <div className="flex gap-6 text-zinc-400">
            <Instagram className="w-5 h-5 hover:text-yellow-400 cursor-pointer transition-colors" />
            <Twitter className="w-5 h-5 hover:text-yellow-400 cursor-pointer transition-colors" />
            <Facebook className="w-5 h-5 hover:text-yellow-400 cursor-pointer transition-colors" />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto border-t border-zinc-900 pt-8 flex flex-col md:flex-row justify-between items-center text-xs text-zinc-600 uppercase tracking-widest">
        <p>&copy; {new Date().getFullYear()} InACan. All rights reserved.</p>
        <div className="flex gap-8 mt-4 md:mt-0">
          <span>Terms</span>
          <span>Privacy</span>
          <span>Cookies</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;