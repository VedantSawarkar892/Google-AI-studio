import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, ShoppingBag } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const links = [
    { name: 'Products', path: '/' }, // Anchors on home usually, but simply routing to home for now
    { name: 'Our Story', path: '/' },
    { name: 'Store Locator', path: '/locator' },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 transition-all duration-300 backdrop-blur-md bg-black/40 border-b border-white/5">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        
        {/* Logo */}
        <Link to="/" className="z-50 relative group">
          <span className="text-2xl font-serif font-bold tracking-tighter group-hover:text-yellow-400 transition-colors">INACAN</span>
        </Link>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center gap-12">
          {links.map((link) => (
            <Link 
              key={link.name} 
              to={link.path} 
              className={`text-sm font-medium uppercase tracking-widest hover:text-yellow-400 transition-colors ${location.pathname === link.path && link.path !== '/' ? 'text-yellow-400' : 'text-zinc-300'}`}
            >
              {link.name}
            </Link>
          ))}
        </div>

        {/* Actions */}
        <div className="hidden md:flex items-center gap-6">
           <button className="relative group">
             <ShoppingBag className="w-5 h-5 text-zinc-300 group-hover:text-yellow-400 transition-colors" />
             <span className="absolute -top-1 -right-1 w-2 h-2 bg-yellow-400 rounded-full"></span>
           </button>
        </div>

        {/* Mobile Toggle */}
        <button className="md:hidden z-50 text-white" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 bg-zinc-950 z-40 flex flex-col items-center justify-center gap-8 md:hidden"
          >
            {links.map((link) => (
              <Link 
                key={link.name} 
                to={link.path} 
                onClick={() => setIsOpen(false)}
                className="text-2xl font-serif font-bold text-white uppercase tracking-widest hover:text-yellow-400"
              >
                {link.name}
              </Link>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;