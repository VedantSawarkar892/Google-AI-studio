import React from 'react';
import { motion } from 'framer-motion';

interface AgeGateProps {
  onVerify: () => void;
}

const AgeGate: React.FC<AgeGateProps> = ({ onVerify }) => {
  const handleVerify = () => {
    localStorage.setItem('age-verified', 'true');
    onVerify();
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] bg-zinc-950 flex items-center justify-center p-6 text-center"
    >
      <div className="max-w-md w-full space-y-8 relative z-10">
        <div className="w-24 h-24 mx-auto bg-white rounded-full flex items-center justify-center mb-8">
           <span className="font-serif font-bold text-3xl text-black">IAC</span>
        </div>
        
        <div className="space-y-4">
            <h1 className="text-4xl font-black tracking-tighter uppercase font-serif">Are you over 18?</h1>
            <p className="text-zinc-400 font-light">
                To enter the InACan Ecosystem, you must be of legal drinking age in your country of residence.
            </p>
        </div>

        <div className="grid grid-cols-2 gap-4 pt-8">
          <button 
            onClick={handleVerify} 
            className="w-full bg-white text-black py-4 font-bold hover:bg-yellow-400 transition-colors uppercase tracking-widest text-sm"
          >
            Yes, I Am
          </button>
          <button 
            className="w-full border border-zinc-700 py-4 font-bold text-zinc-400 hover:text-white hover:border-white transition-colors uppercase tracking-widest text-sm"
            onClick={() => window.location.href = 'https://google.com'}
          >
            No
          </button>
        </div>
        <p className="text-xs text-zinc-600 mt-8 uppercase tracking-widest">Drink Responsibly</p>
      </div>

      {/* Background Texture */}
      <div className="absolute inset-0 opacity-20 pointer-events-none bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
    </motion.div>
  );
};

export default AgeGate;