import React, { useState } from 'react';
import { MapPin, Navigation } from 'lucide-react';
import { STORES } from '../constants';
import { motion } from 'framer-motion';

const StoreLocator: React.FC = () => {
  const [activeStore, setActiveStore] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-zinc-950 pt-24 pb-12 px-6">
      <div className="max-w-7xl mx-auto h-[80vh] grid lg:grid-cols-3 gap-8 rounded-2xl overflow-hidden border border-zinc-800 bg-zinc-900/50">
        
        {/* Sidebar List */}
        <div className="lg:col-span-1 border-r border-zinc-800 flex flex-col h-full">
          <div className="p-8 border-b border-zinc-800">
             <h1 className="text-3xl font-serif font-bold mb-4">FIND US</h1>
             <div className="relative">
                <input 
                  type="text" 
                  placeholder="Enter your city or zip code" 
                  className="w-full bg-zinc-950 border border-zinc-800 p-4 pl-12 text-sm text-white focus:outline-none focus:border-yellow-400 transition-colors"
                />
                <MapPin className="absolute left-4 top-1/2 transform -translate-y-1/2 w-4 h-4 text-zinc-500" />
             </div>
          </div>
          
          <div className="flex-1 overflow-y-auto custom-scrollbar">
            {STORES.map((store) => (
              <div 
                key={store.id} 
                onClick={() => setActiveStore(store.id)}
                className={`p-6 border-b border-zinc-800/50 cursor-pointer transition-colors ${activeStore === store.id ? 'bg-zinc-800' : 'hover:bg-zinc-800/30'}`}
              >
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-bold text-lg">{store.name}</h3>
                  <span className={`text-[10px] uppercase tracking-widest px-2 py-1 rounded border ${store.type === 'Partner Bar' ? 'border-yellow-400 text-yellow-400' : 'border-zinc-600 text-zinc-400'}`}>
                    {store.type}
                  </span>
                </div>
                <p className="text-zinc-400 text-sm mb-4">{store.address}</p>
                <button className="flex items-center text-xs text-yellow-400 uppercase tracking-widest font-bold hover:text-white transition-colors">
                  <Navigation className="w-3 h-3 mr-2" /> Get Directions
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Map Placeholder */}
        <div className="lg:col-span-2 relative bg-zinc-800 hidden lg:block">
           {/* In a real implementation, Google Maps API would be loaded here using the lat/lng from STORES */}
           <div className="absolute inset-0 opacity-50">
              <img 
                src="https://picsum.photos/seed/map/1200/800" 
                alt="Map View" 
                className="w-full h-full object-cover grayscale invert"
              />
           </div>
           
           <div className="absolute inset-0 flex items-center justify-center">
              <div className="bg-zinc-950/90 backdrop-blur border border-zinc-700 p-8 rounded-xl max-w-sm text-center">
                 <MapPin className="w-10 h-10 text-yellow-400 mx-auto mb-4" />
                 <h3 className="text-xl font-bold mb-2">Interactive Map Area</h3>
                 <p className="text-zinc-400 text-sm">
                   This area integrates with Google Maps API using the provided JSON coordinates.
                   Select a location from the left to center the view.
                 </p>
              </div>
           </div>

           {/* Mock Markers */}
           {STORES.map((store, idx) => (
             <motion.div
               key={store.id}
               initial={{ scale: 0 }}
               animate={{ scale: 1 }}
               transition={{ delay: idx * 0.1 }}
               className={`absolute w-4 h-4 rounded-full border-2 border-zinc-950 shadow-lg cursor-pointer transform -translate-x-1/2 -translate-y-1/2
                 ${activeStore === store.id ? 'bg-yellow-400 w-6 h-6 z-10' : 'bg-white z-0'}
               `}
               style={{ 
                 top: `${30 + (idx * 15)}%`, 
                 left: `${20 + (idx * 20)}%` 
               }}
               title={store.name}
               onClick={() => setActiveStore(store.id)}
             />
           ))}
        </div>
      </div>
    </div>
  );
};

export default StoreLocator;