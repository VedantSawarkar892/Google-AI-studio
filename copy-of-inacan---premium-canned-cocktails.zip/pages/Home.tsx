import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { PRODUCTS, getFallbackImage } from '../constants';
import WhyInACan from '../components/WhyInACan';
import PressSlider from '../components/PressSlider';

const Home: React.FC = () => {
  return (
    <div className="bg-zinc-950">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1544145945-f90425340c7e?auto=format&fit=crop&w=1920&q=80"
            alt="Hero Background" 
            className="w-full h-full object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/50 to-transparent"></div>
        </div>

        <div className="relative z-10 text-center px-6 max-w-4xl mx-auto mt-20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-yellow-400 tracking-[0.4em] uppercase text-sm font-bold mb-6">Premium Canned Cocktails</h2>
            <h1 className="text-5xl md:text-7xl lg:text-9xl font-serif font-bold tracking-tighter mb-8 text-white drop-shadow-2xl">
              UNCANNED.
            </h1>
            <p className="text-zinc-300 text-lg md:text-xl max-w-2xl mx-auto mb-12 font-light">
              Experience the art of mixology in a can. Crafted by award-winning bartenders for the moments that matter.
            </p>
            <div className="flex flex-col md:flex-row gap-6 justify-center">
               <a href="#products" className="bg-white text-black px-8 py-4 uppercase tracking-widest font-bold text-sm hover:bg-yellow-400 transition-colors">
                 Shop Collection
               </a>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Products Grid */}
      <section id="products" className="py-32 px-6 max-w-7xl mx-auto">
        <div className="text-center mb-24">
            <h3 className="text-3xl md:text-4xl font-serif mb-4">OUR COLLECTION</h3>
            <div className="w-24 h-1 bg-yellow-400 mx-auto"></div>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-16">
          {PRODUCTS.map((product) => (
            <Link key={product.id} to={product.path} className="group block">
              <motion.div 
                whileHover={{ y: -10 }}
                className="relative"
              >
                <div className="aspect-[4/5] overflow-hidden bg-zinc-900 rounded-sm mb-6 relative">
                  <div className={`absolute inset-0 bg-${product.accent}-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500`}></div>
                  <img 
                    src={product.image} 
                    onError={(e) => {
                      e.currentTarget.src = getFallbackImage(product.title);
                    }}
                    alt={product.title} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" 
                  />
                  {/* Overlay Button */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <span className="bg-white/10 backdrop-blur-md text-white border border-white/20 px-6 py-3 uppercase text-xs tracking-widest font-bold">
                      View Details
                    </span>
                  </div>
                </div>
                <div className="text-center">
                  <h4 className="text-2xl font-serif font-bold mb-2 group-hover:text-yellow-400 transition-colors">{product.title}</h4>
                  <p className="text-zinc-500 text-sm uppercase tracking-wider">{product.description}</p>
                </div>
              </motion.div>
            </Link>
          ))}
        </div>
      </section>

      <WhyInACan />
      <PressSlider />
    </div>
  );
};

export default Home;