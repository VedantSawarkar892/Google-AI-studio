import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Check, ShoppingBag } from 'lucide-react';
import { Link } from 'react-router-dom';
import { getFallbackImage } from '../constants';

interface ProductPageProps {
  title: string;
  desc: string;
  img: string;
  accent: string;
}

const ProductPage: React.FC<ProductPageProps> = ({ title, desc, img, accent }) => {
  // Map accent names to tailwind colors for inline styles since dynamic class generation is tricky in Tailwind JIT without safelist
  const accentColors: Record<string, string> = {
    blue: '#3b82f6',
    pink: '#ec4899',
    green: '#22c55e',
    orange: '#f97316',
    yellow: '#eab308',
  };

  const accentHex = accentColors[accent] || '#ffffff';

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-20 relative overflow-hidden"
    >
      {/* Dynamic Background Glow */}
      <div 
        className="absolute top-0 right-0 w-[500px] h-[500px] rounded-full blur-[150px] opacity-20 pointer-events-none"
        style={{ backgroundColor: accentHex }}
      ></div>

      <div className="max-w-7xl mx-auto px-6 py-12 relative z-10">
        <Link to="/" className="inline-flex items-center text-zinc-400 hover:text-white mb-12 text-sm uppercase tracking-widest transition-colors">
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to Collection
        </Link>

        <div className="grid md:grid-cols-2 gap-16 items-center">
          <motion.div 
            initial={{ x: -50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="relative aspect-square bg-zinc-900/50 rounded-2xl overflow-hidden border border-white/5"
          >
             <img 
                src={img} 
                onError={(e) => {
                  e.currentTarget.src = getFallbackImage(title);
                }}
                alt={title} 
                className="w-full h-full object-cover" 
             />
          </motion.div>

          <motion.div 
            initial={{ x: 50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="space-y-8"
          >
            <div>
              <span className="text-yellow-400 font-bold uppercase tracking-widest text-xs mb-2 block">Premium Cocktail</span>
              <h1 className="text-5xl md:text-7xl font-serif font-bold text-white mb-4">{title}</h1>
              <p className="text-xl text-zinc-400 font-light">{desc}</p>
            </div>

            <div className="flex items-center gap-6 py-6 border-y border-white/10">
              <div className="text-3xl font-serif">8% <span className="text-xs text-zinc-500 uppercase font-sans tracking-wide block">ABV</span></div>
              <div className="w-px h-12 bg-white/10"></div>
              <div className="text-3xl font-serif">250 <span className="text-xs text-zinc-500 uppercase font-sans tracking-wide block">ml</span></div>
              <div className="w-px h-12 bg-white/10"></div>
              <div className="text-3xl font-serif">55 <span className="text-xs text-zinc-500 uppercase font-sans tracking-wide block">Cal</span></div>
            </div>

            <p className="text-zinc-400 leading-relaxed">
              A sophisticated blend that defies expectations. Perfectly balanced, expertly crafted, and ready to enjoy. 
              Pour over ice for the best experience.
            </p>

            <div className="space-y-3">
              {['No Preservatives', 'Natural Ingredients', 'Bar Quality'].map((feature) => (
                <div key={feature} className="flex items-center text-zinc-300">
                  <Check className="w-4 h-4 text-yellow-400 mr-3" />
                  <span className="text-sm uppercase tracking-wider">{feature}</span>
                </div>
              ))}
            </div>

            <div className="pt-8">
              <button className="w-full md:w-auto bg-white text-black px-12 py-5 uppercase tracking-widest font-bold text-sm hover:bg-yellow-400 transition-colors flex items-center justify-center gap-3 group">
                <ShoppingBag className="w-4 h-4" /> Add to Cart — $12.99
              </button>
            </div>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
};

export default ProductPage;